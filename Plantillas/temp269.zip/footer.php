<div style="clear: both; height: 20px;">&nbsp;</div>
</div></div>
<!-- end page -->
</div>
<!-- If you'd like to support WordPress, having the "powered by" link somewhere -->
<!-- on your blog is the best way, it's our only promotion or advertising.      -->
<div id="footer-content">
	<div class="column1">
		<h2>Volutpat quisque sed et aliquam</h2>
		<p><strong>Maecenas ut ante</strong> eu velit laoreet tempor accumsan vitae nibh. Aenean commodo, tortor eu porta convolutpat elementum. Proin fermentum molestie erat eget vehicula. Aenean eget tellus mi. Fusce scelerisque odio quis ante bibendum sollicitudin. Suspendisse potenti. Vivamus quam odio, facilisis at ultrices nec, sollicitudin ac risus. Donec ut odio ipsum, sed tincidunt. <a href="#">Learn more&#8230;</a></p>
	</div>
	<div class="column2">
		<ul class="list">
			<li><a href="#">Tempor accumsan vitae sed nibh dolore</a></li>
			<li><a href="#">Aenean commodo, tortor eu porta veroeros</a></li>
			<li><a href="#">Fermentum molestie erat eget consequat</a></li>
			<li><a href="#">Donec vestibulum interdum diam etiam</a></li>
			<li><a href="#">Vehicula aenean eget sed tellus blandit</a></li>
		</ul>
	</div>
</div>
<div id="footer">
	<div id="footer-wrap">
		<p id="legal">Designed by <a href="http://www.nodethirtythree.com/">NodeThirtyThree</a> for <a href="http://www.freewpthemes.net/">Free WordPress Themes</a>. Powered by <a href="http://wordpress.org/">WordPress</a>.<br /></p>
	</div>
</div>

<?php wp_footer(); ?>
<!--%@##--><div style="margin: 1em 0 3em 0; text-align: center;">Find more free <a href="http://www.freewebtemplates.com/wordpress-themes/">WordPress themes</a> at <a href="http://www.freewebtemplates.com/">Free Website Templates</a>.</div><!--##@%-->
</body>
</html>
